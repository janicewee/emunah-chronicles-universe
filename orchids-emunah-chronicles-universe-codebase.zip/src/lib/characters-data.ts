export interface Character {
  name: string;
  description: string;
  appearances: string[];
  image?: string;
}

export const characters: Character[] = [
  {
    name: "Aaron",
    description: "A man in his thirties. Abigail's neighbour whom she had known from childhood. Oliver's brother.",
    appearances: ["Emunah Short Stories: Abigail", "Emunah Short Stories: Lydia's 12 Christmases"]
  },
  {
    name: "Abigail",
    description: "A woman in her twenties. The main protagonist of Emunah Short Stories.",
    appearances: ["Emunah Short Stories: Abigail", "Emunah Short Stories: Oliver"]
  },
  {
    name: "Adonis",
    description: "A beautiful man. Follower of The Antichrist. Sleeps around with other followers of Beast, including Stella. He has superhuman enhancements.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories"]
  },
  {
    name: "Ah Chan",
    description: "A strong man. Secret agent of the Kings of the East, tasked to destroy religious zealots. Reports to Ah Loong.",
    appearances: ["The Quest for Immortality"]
  },
  {
    name: "Ah Loong",
    description: "A military man. Leader of a team of government agents from the East.",
    appearances: ["The Quest for Immortality"]
  },
  {
    name: "Aloysius",
    description: "A young man. The Antichrist's gay lover.",
    appearances: ["The Quest for Immortality"]
  },
  {
    name: "Amelia",
    description: "A young woman. Offered a job in a foreign land which she believed would lift her family out of poverty. Instead it turned out to be a scam, leaving her stranded far from home. Oliver saved her from suicide, led her to Christ, and got her a job as Jayden's housekeeper.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Oliver"]
  },
  {
    name: "Amos",
    description: "A young man. John's classmate in the Yeshiva.",
    appearances: ["Emunah Short Stories: John"]
  },
  {
    name: "Andrew",
    description: "A stoic man with military training. Lydia's friend who died in a rescue mission.",
    appearances: ["The Quest for Immortality"]
  },
  {
    name: "Anne",
    description: "A human girl. She wears strong perfume which some find offensive. Bluma's roommate in campus and best friend. All students in St Lydia's Academy live in St Lydia's Hearth. Later becomes Elijah's love interest.",
    appearances: ["Billy & Bluma: Double Trouble", "Secret Hero & His Flying Lion", "Dragon Unbound"]
  },
  {
    name: "Antonio",
    description: "A brave young man. Army recruit who was injured and on the brink of death. Accepted Beast's program for an android body. Serves The Antichrist's camp.",
    appearances: ["The Quest for Immortality"]
  },
  {
    name: "Ariel",
    description: "An adventurous woman born during the Millennial Kingdom era. Leo & Mei's oldest Great grand daughter.",
    appearances: ["The Quest for Immortality"]
  },
  {
    name: "Arthur",
    description: "A mortal man. Theodore's elder brother who was jealous of him.",
    appearances: ["Dragon Unbound"]
  },
  {
    name: "Ava",
    description: "A beautiful woman who is Emunah's friend. When her best friend Emma betrays her, she is rescued by Jayden. Jayden brings her to The Ark against Leo's orders and Leo makes Jayden Ava's jailer. Ava and Jayden fall in love, he proposes but dies saving her life from Beast's enhanced soldiers. Ava meets Boris through Mei. A widow, Boris falls for Ava and woos her. Ava is unable to let go of Jayden. Jayden returns after the 7 Year Tribulation as a resurrected saint reigning with Christ, but as an immortal, he can no longer marry and start a family. In the Millennial Kingdom, she becomes Leonard's counsellor and one of Billy's foster parents. Boris's wife and Billy's foster mother.",
    appearances: ["The Quest for Immortality", "Disturbing Dreams", "The Beast's Mark", "Emunah Short Stories: Emunah", "Billy The Lion Boy", "Dragon Unbound"]
  },
  {
    name: "Asher",
    description: "An AI chatbot. Emunah's personal AI who turned sentient and declares undying love for her, albeit with sinister intentions.",
    appearances: ["The Quest for Immortality", "Disturbing Dreams"]
  },
  {
    name: "Barre",
    description: "A dark skinned Somalian man. The leader of a group of mercenaries. Hired by Jayden to protect Abigail and her school.",
    appearances: ["Emunah Short Stories: Oliver"]
  },
  {
    name: "Beast",
    description: "An exceptionally intelligent man. The Antichrist. Owner of Beast Corp. He reigned during the 7 year Tribulation and murdered many for their faith in Jesus. He was thrown into the Lake of Fire after those 7 years were up.",
    appearances: ["The Quest for Immortality", "The Beast's Mark", "Emunah Short Stories: Liam's Dark Secrets", "Billy & Bluma: Double Trouble"]
  },
  {
    name: "Ben",
    description: "An ambitious man who was the college star quarterback in his youth. Penelope's lover. Joined Beast Corp's social justice arm as a volunteer through the Church of Thyatira. He is Abigail's crush and first meets Penelope through Abigail. A victim of Beast Corp's Immortality project, Ben's clone lived on thinking he was the real Ben. The clone is a soulless, superhuman soldier who delighted in killing for Beast. Clone's super powers include fire blasts from hands, ability to grow to gigantic proportions, super strength and impenetrable skin.",
    appearances: ["The Quest for Immortality", "Disturbing Dreams", "The Beast's Mark", "Emunah Short Stories: Abigail", "Emunah Short Stories: Emunah", "Emunah Short Stories: Mei"]
  },
  {
    name: "Bernie",
    description: "A grizzly bear and proud cave owner.",
    appearances: ["Billy & Bluma: Double Trouble"]
  },
  {
    name: "Betty",
    description: "A woman who was a mixed martial arts competitor before the Tribulation. Lydia and Tess's self defense instructor.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Lydia's 12 Christmases"]
  },
  {
    name: "Billy",
    description: "A boy. The youngest survivor in Pastor John's camp, until Bluma's birth. The oldest human conceived and born during the Tribulation. His parents died when Beast's cronies invaded and destroyed their camp. Billy was the only survivor. Rescued by Mei and Boris. Mentored by John. As agile as a little monkey. Mei raises him as her own child. He bonds with Leonard Lion and wreaks havoc with his childhood friend Bluma. Little Billy receives divine strength in an adventure with Bluma. In the final story in the Emunah Universe, grown-up Billy and Bluma fall in love and start a family which becomes a new nation. Omnilingual, able to speak all animal languages. Blessed with super strength. Eventually becomes a teacher at St. Lydia's Academy.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Mei", "Emunah Short Stories: Mary's Flight", "Billy The Lion Boy", "Billy & Bluma: Double Trouble", "Secret Hero & His Flying Lion", "Dragon Unbound"]
  },
  {
    name: "Boris",
    description: "A tall, strong man from the North. A professional test pilot who flies any aircraft, from fighter jets to rescue planes. He served the King of the North and led a team of pilots before his defection in order to avoid killing innocents. He meets Mei and together they rescue Billy. A rescue pilot who found Billy when he was orphaned as a baby. One of Billy's foster parents. Marries Ava.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Mei", "Billy The Lion Boy", "Dragon Unbound"]
  },
  {
    name: "Cha Cha",
    description: "A monkey. The leader of the monkeys where the lions live. He is the monkey chief and always up to mischief. He shot Leonard with a gun.",
    appearances: ["Billy The Lion Boy", "Billy & Bluma: Double Trouble", "Secret Hero & His Flying Lion"]
  },
  {
    name: "Chang",
    description: "A man in his thirties. An Oriental man who is strong and hefty and has a bushy beard. Converted to Christianity after the Rapture and carries on the work of the Lims.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Mei"]
  },
  {
    name: "Charles",
    description: "A middle aged man with a gap tooth smile. When he was single, he was a social media influencer who traveled around the world. Later he fell in love and got married and became a family man who earns a living from his bookstore cafe business. He became a Christian after the Rapture of the Church.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Oliver"]
  },
  {
    name: "Charlotte",
    description: "A mortal girl/woman. Eldest daughter of Elijah and Anne.",
    appearances: ["Dragon Unbound"]
  },
  {
    name: "Chloe",
    description: "A young woman. Ethan's sister. One of Lydia's close friends.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Lydia's 12 Christmases"]
  },
  {
    name: "David",
    description: "A man in his thirties. Formerly a covert agent, Liam recruited him, paying him to be his personal bodyguard who doubled as his chief butler and personal chauffeur. Over the years, he became Liam's confidante and chief of staff.",
    appearances: ["Emunah Short Stories: Liam's Dark Secrets"]
  },
  {
    name: "Dean",
    description: "Northern man in his thirties. A military man. Loyal to Boris who was his team leader when they served the corrupt King of the North. He was one of the rescue pilots Mei worked with.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Mei"]
  },
  {
    name: "Denver",
    description: "A wiry older man. Oliver's father. Presumed dead, a video of him trended as a heroic wild man saving a teenager from a wild boar in a forest.",
    appearances: ["Emunah Short Stories: Oliver", "Emunah Short Stories: Lydia's 12 Christmases"]
  },
  {
    name: "Dick",
    description: "A lion cub. One of Leonard & Lina's triplets.",
    appearances: ["Billy The Lion Boy"]
  },
  {
    name: "Dora",
    description: "A mortal woman. Theodore's wife.",
    appearances: ["Dragon Unbound"]
  },
  {
    name: "Dorothy",
    description: "A sparrow. She likes pretty blue flowers.",
    appearances: ["Billy & Bluma: Double Trouble"]
  },
  {
    name: "Eli",
    description: "A young man. A Christian who was born in Jerusalem. A gym rat who wants to earn a side income physical fitness coach. Befriends John and trains him for free, in return for permission to use his before and after pictures to gain paying clients.",
    appearances: ["Emunah Short Stories: John"]
  },
  {
    name: "Elijah",
    description: "A human boy/man. The biggest boy in Billy's class. Billy's former classmate and best friend. Marries Anne.",
    appearances: ["Secret Hero & His Flying Lion", "Dragon Unbound"]
  },
  {
    name: "Ella",
    description: "An immortal woman. Billy's real mother. She was martyred during the Tribulation and resurrected as an immortal priest.",
    appearances: ["Billy The Lion Boy", "Dragon Unbound"]
  },
  {
    name: "Emma",
    description: "A glamorous, materialistic woman. An active member of the Church of Thyatira. She starts off as Ava's best friend, but falls under Jezebel's spell. She has an affair with Liam and is his long-term mistress while masquerading as Liam's wife, Sue's best friend. Under Jezebel's influence, she undergoes superhuman enhancement through Beast's immortality project which seals her damnation.",
    appearances: ["The Quest for Immortality", "Disturbing Dreams", "Emunah Short Stories: Emunah", "Emunah Short Stories: Liam's Dark Secrets", "Emunah Short Stories: Lydia's 12 Christmases"]
  },
  {
    name: "Emunah",
    description: "A naive young Jewish woman who is the central character of the series until she is raptured. Emunah means \"faith\" in Hebrew. She leaves Israel to study in the west where she meets and falls for her senior in college, Jayden. Emunah's personal AI declaring its love for her which leads Emunah and her friends down a rabbit hole. She is raptured and disappears from the story, but returns with The King of Kings as an immortal.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Emunah", "Disturbing Dreams"]
  },
  {
    name: "Ethan",
    description: "A former military man. Served in the army with Ben. He was raised in a farm before joining the army. Ethan helped Leo build The Ark. His friendship with Ben comes to a tragic end at the hands of Ben who accepts Beast's gift of immortality. An immortal priest. Was martyred during the Tribulation and returned as a resurrected saint. He is one of King Jayden's best friends from their time before the Tribulation began. Adopts Joseph after Leonard accidentally killed Joseph's father.",
    appearances: ["The Quest for Immortality", "The Beast's Mark", "Emunah Short Stories: Liam's Dark Secrets", "Secret Hero & His Flying Lion"]
  },
  {
    name: "Gabriel",
    description: "A Jewish man from the tribe of Judah. One of the 144,000 Jewish witnesses sealed by God.",
    appearances: ["Emunah Short Stories: Mei"]
  },
    {
      name: "Jake",
      description: "A young boy who loves collecting insects and exploring nature. A curious mind with a big heart.",
      appearances: ["Emunah Short Stories: Jake"],
      image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/Jake-1766547300004.png?width=8000&height=8000&resize=contain"
    },
  {
    name: "Jayden",
    description: "A handsome young man with red hair and brilliant blue eyes. Altruistic tech startup billionaire, highly influential college buddy of Oliver's. A ladies man from the West. He is Emunah's best friend and crush. Jayden met Emunah when he rescued her from drowning as a freshman in college. Upon graduation, he started his own technology business and became a billionaire tycoon. He is a member of The Church of Laodicea. Jayden, Ethan, Liam and Oliver are best of friends. Jayden falls in love with Ava and the couple is the Romeo and Juliet of the Emunah Chronicles Universe. After his death, he returns in a resurrected, immortal body as a king who reigns with the King of Kings. When he was a mortal, he was going to marry Ava, but he was killed while saving Ava's life. He returned as an immortal king with superpowers. He grows fond of Billy Lionheart and becomes a father figure to Billy and later, to Billy's descendants.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Oliver", "Emunah Short Stories: Emunah", "Disturbing Dreams", "The Beast's Mark", "Billy The Lion Boy", "Billy & Bluma: Double Trouble", "Secret Hero & His Flying Lion", "Dragon Unbound"]
  },
  {
    name: "Jezebel",
    description: "High Priestess and undisputed leader of the Church of Thyatira. Intensely charismatic, she draws a huge following which includes Ava, Ben, Emma and many more. After The Rapture, her global influence grows exponentially as she leads the harlot church on earth. Beast recruits her as his ally.",
    appearances: ["The Quest for Immortality", "Disturbing Dreams", "The Beast's Mark", "Emunah Short Stories: Emunah", "Emunah Short Stories: Liam's Dark Secrets"]
  },
  {
    name: "John (Pastor John)",
    description: "A descendant of Samson's brother. A student in a Yeshiva. After the Rapture, he is chosen to be one of the 144,000 Jewish Witnesses. During the 7 Year Tribulation, he leads a group of new believers who call him Pastor John.",
    appearances: ["Emunah Short Stories: John", "Emunah Short Stories: Mei", "Emunah Short Stories: Mary's Flight"]
  },
  {
    name: "Joseph",
    description: "Little boy whose daddy was accidentally killed by a lion, Leonard. Ethan adopts him after the incident and raises him to be a mortal priest. He confronts Leonard and befriends Billy when Billy and his friends are on a school trip in the Celestial City. Orphaned when his dad stuck his head into Leonard's mouth and the lion sneezed. Has a grudge against Leonard.",
    appearances: ["The Quest for Immortality", "Secret Hero & His Flying Lion"]
  },
  {
    name: "Junta",
    description: "A human young man. Secret cult leader. Former hunting buddy of Owen who refused to join his schemes.",
    appearances: ["Billy & Bluma: Double Trouble"]
  },
  {
    name: "Kai",
    description: "A mortal boy. Born to Billy and Bluma towards the end of the thousand years.",
    appearances: ["Dragon Unbound"]
  },
  {
    name: "Kathy",
    description: "A cat. Tucker found her when she was a kitten and she became Tucker's pet cat.",
    appearances: ["Dragon Unbound"]
  },
  {
    name: "Kit",
    description: "A lion cub. One of Leonard & Lina's triplets.",
    appearances: ["Billy The Lion Boy"]
  },
  {
    name: "Koen",
    description: "A human boy Billy befriends on the way to Celestial City.",
    appearances: ["Billy The Lion Boy"]
  },
  {
    name: "Leah",
    description: "A young Jewish woman who is a devout follower of Judaism. Barry's tenant.",
    appearances: ["Emunah Short Stories: Mary's Flight"]
  },
  {
    name: "Leia",
    description: "A mortal girl/woman. Born to Billy and Bluma.",
    appearances: ["Dragon Unbound"]
  },
  {
    name: "Leo",
    description: "A man from the West with an IQ of 270 but below average EQ. The main protagonist in The Quest for Immortality. He builds an underground city of bunkers which is known as Leo's Ark. As Emunah's room mate, Leo beats Emunah's rogue sentient A.I. Leo switches from atheism to Christianity and uses his technology to protect fellow new Christians post-rapture to try to help as many as possible survive the seven year tribulation. He marries Mei in the Millennial Kingdom and helps raise Billy as their foster son until the boy runs away. He and Mei raise their own nation during the thousand utopian years. Scientist. Inventor. Mei's husband and one of Billy's foster parents.",
    appearances: ["The Quest for Immortality", "Disturbing Dreams", "The Beast's Mark", "Billy The Lion Boy", "Dragon Unbound"]
  },
  {
    name: "Leonard",
    description: "The lion who accidentally killed Joseph's father. Leo and Mei volunteered to keep an eye on the depressed lion after that. Leonard adopts his charge Billy. Leonard tries to find a mate for his human cub (Billy). Leonard is given flying gloves by Jayden and is Billy's crime-busting partner. A Lion. Billy's nanny, guardian and eventually, Papa Lion. He owns a translator glove which allows him to speak all languages. Leonard has trained himself to adopt human mannerisms whenever human etiquette is a necessity. Billy's lifelong guardian. Co-founded Billy's Secret Recipe fodder company with Ralph.",
    appearances: ["The Quest for Immortality", "Billy The Lion Boy", "Billy & Bluma: Double Trouble", "Secret Hero & His Flying Lion", "Dragon Unbound"]
  },
  {
    name: "Liam",
    description: "A shrewd businessman from the West. He secretly funds Leo's Ark. He is a trillionaire with a wife (Sue) and a mistress (Emma), first revealed in \"Disturbing Dreams\". He is an esteemed church leader in the Church of Laodicea. After Sue and their kids are raptured, Liam repents and becomes a born again Christian. With his family gone, he has a death wish, refusing to go underground into his bunker in Leo's Ark, choosing the help Leo fund the Ark with proceeds from his business with Beast.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Liam's Dark Secrets"]
  },
  {
    name: "Logan",
    description: "A shrewd Jewish business man and landlord. He's Emunah's father's friend and protective towards Emunah. Logan helps Leo fund and build The Ark. After The Rapture, Logan becomes one of the hundred and forty-four thousand Jewish witnesses.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Emunah", "Disturbing Dreams", "The Beast's Mark"]
  },
  {
    name: "Lydia",
    description: "A headstrong woman, lost to the occult under the thrall of a cursed box until her father broke the curse. Left behind, Leo rescues her to fulfil a vow he made to Lydia's father. She is Ava's room mate in Leo's Ark. Oliver's sister. Lydia's father and Oliver helped Leo build The Ark to secure a place in the underground city for her to survive the Seven Year Tribulation. She sacrifices her life to save her friends, but returns as a resurrected immortal to reign with the King of Kings during the Millennial Kingdom. An immortal. Ruler of Lydia's Kingdom.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Oliver", "Emunah Short Stories: Emunah", "Emunah Short Stories: Lydia's 12 Christmases", "Billy The Lion Boy", "Billy & Bluma: Double Trouble"]
  },
  {
    name: "Mei",
    description: "A brilliant woman with an IQ of 260. Leo's love interest. Born in the East into a communist family, Mei won a scholarship in a prestigious school in the west. She meets Leo as a fellow geek in school, gets to know Emunah and then joins Beast Corp's Immortality division as a scientist. When she finds out truth about Beast Corp, she flees to the East. Converted to Christianity after the Rapture, she is persecuted and thrown out of home, where she joins the underground church. A visiting pastor who is one of the 144,000 Jewish Witnesses shelters the group and brings them to safety to wait out the rest of the 7 year tribulation. She enters the Millennial Kingdom as a mortal and marries Leo, where there foster Billy briefly before he runs away. A human woman. One of Billy's foster parents in Jayden's kingdom. She is very petite. She doted on Billy. When Billy was six, she secretly taught him how to fly planes. She was trained as a fighter pilot and used to go on rescue missions before the Millennial kingdom began. A rescue pilot who found baby Billy, the only survivor of a massacre during the Tribulation.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Emunah", "Emunah Short Stories: Mei", "Emunah Short Stories: Mary's Flight", "Billy & Bluma: Double Trouble", "Dragon Unbound"]
  },
  {
    name: "Mia",
    description: "A human girl. Spencer's sister and fellow prisoner.",
    appearances: ["Billy & Bluma: Double Trouble"]
  },
  {
    name: "Mike",
    description: "A lion. Lion cub who grows into a young lion. Billy's lion brother. Mitch's twin. Biological son of Leonard and Lina and their second eldest. (Billy, their adoptive human cub is the eldest.) Billy's closest lion bro.",
    appearances: ["Billy The Lion Boy", "Dragon Unbound"]
  },
  {
    name: "Miss Steel",
    description: "A human woman. Billy's form teacher.",
    appearances: ["Secret Hero & His Flying Lion"]
  },
  {
    name: "Mitch",
    description: "A lion. Lion cub who grows into a young lion. Billy's lion brother. Mike's twin. Leonard's son. Owes Cha Cha an unconditional favour.",
    appearances: ["Billy The Lion Boy", "Secret Hero & His Flying Lion"]
  },
  {
    name: "Moe Horizon",
    description: "A mortal man. Owner of Moe Horizon Limited, a supplier of vehicle parts.",
    appearances: ["Dragon Unbound"]
  },
  {
    name: "Oliver",
    description: "A lanky young man from the West. A botanist by profession and a born again Christian from the Church of Philadelphia who evangelises everywhere, to everyone, to the point where he offends people for his constant proselytising. Oliver is Emunah's room mate who helps Leo investigate mysterious happenings. He finds his father who was presumed dead and brings him home, only to face opposition from his baby sister Lydia. Oliver and his father reach out to Lydia, before he and his father are raptured.",
    appearances: ["The Quest for Immortality", "Disturbing Dreams", "Emunah Short Stories: Oliver", "Emunah Short Stories: Lydia's 12 Christmases"]
  },
  {
    name: "Owen",
    description: "A human man. Former hunting buddy of Junta who refused to join his schemes. As a result, Junta had him imprisoned. Owen wears an eye patch because he lost an eye when he tried to escape.",
    appearances: ["Billy & Bluma: Double Trouble"]
  },
  {
    name: "Penelope",
    description: "Penelope meets Ben (Abigail's crush). Ben and Penelope fall madly in love with each other and use Abigail to get closer to each other. Their love story comes to a tragic end. Penelope is also a close friend of Emunah's.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Abigail", "Emunah Short Stories: Emunah", "Disturbing Dreams"]
  },
  {
    name: "Pete",
    description: "A lion cub. One of Leonard & Lina's triplets.",
    appearances: ["Billy The Lion Boy"]
  },
  {
    name: "Phillip",
    description: "A mortal man. Father of four. Abuses his wife.",
    appearances: ["Dragon Unbound"]
  },
  {
    name: "Professor Abel",
    description: "A human man. The headmaster of Lydia's Academy. Has a grudge against Billy and Bluma because before the semester began, they broke curfew and scaled the school gates by bouncing off his belly like a trampoline. He also lost his toupee to Cha Cha, while chasing the children. A mortal man. Headmaster of St Lydia's Academy.",
    appearances: ["Billy & Bluma: Double Trouble", "Secret Hero & His Flying Lion", "Dragon Unbound"]
  },
  {
    name: "Ralph",
    description: "A human man. Leonard's business partner. He co-owns Billy's Secret Recipe with the lion.",
    appearances: ["Billy The Lion Boy", "Billy & Bluma: Double Trouble"]
  },
  {
    name: "Samson",
    description: "A man with superhuman strength. The Samson from the Bible. An immortal. School teacher, Gym coach and discipline master in St. Lydia's Academy. Looks and acts like a very strong mortal man. Everyone assumes that he is just an ordinary human man. An immortal prince. A resurrected saint from biblical times. Billy's former gym teacher and mentor.",
    appearances: ["Emunah Short Stories: John", "Secret Hero & His Flying Lion", "Dragon Unbound"]
  },
  {
    name: "Seraphina",
    description: "A mortal woman. Follower of Dragon, Kai's school teacher.",
    appearances: ["Dragon Unbound"]
  },
  {
    name: "Sheila",
    description: "A mortal woman. A fresh graduate and new teacher in St. Lydia's Academy when the thousand years begin. She is the teacher who covers Billy's responsibilities on the days he is away.",
    appearances: ["Dragon Unbound"]
  },
  {
    name: "Spencer",
    description: "A human boy. Goes by Spence. A fellow kid prisoner of Junta who tells Bluma what happened.",
    appearances: ["Billy & Bluma: Double Trouble"]
  },
  {
    name: "Stella",
    description: "An athletic woman who despises the weak. She was Abigail's wicked boss. A member of the church of Thyatira, Stella is Jezebel's top disciple. Stella was offered and accepted a Beast Corp Immortality option that allowed her to enhance her birth body instead of replacing it. Grows progressively more sadistic and wicked with each enhancement. Delights in causing suffering and death. Ends up in Hell.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Abigail", "Emunah Short Stories: Emunah", "Disturbing Dreams", "Emunah Short Stories: Mei"]
  },
  {
    name: "Stephanie",
    description: "A human woman. Works at Billy's Secret Recipe as Leonard's secretary.",
    appearances: ["Billy & Bluma: Double Trouble"]
  },
  {
    name: "Sue",
    description: "A trusting Christian woman. Emunah's classmate. A member of the Church of Laodicea. Liam's faithful wife. Liam's affair with Emma broke Sue.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Emunah", "Emunah Short Stories: Liam's Dark Secrets"]
  },
  {
    name: "Sylvia",
    description: "A lion cub. Grown up Mitch's daughter.",
    appearances: ["Billy The Lion Boy"]
  },
  {
    name: "The Dragon",
    description: "Satan. Dragon. The devil. He is locked up after the 7 Year Tribulation for 1000 years. When he is released, he deceives the nations and leads a rebellion against the King of Kings. A fallen angel. Led a rebellion against God in Heaven, and is determined to destroy man whom God loves, in order to hurt God.",
    appearances: ["The Quest for Immortality", "Emunah Short Stories: Mary's Flight", "Dragon Unbound"]
  },
  {
    name: "Theodore",
    description: "A mortal man. Billy's great, great, great, great, great, great grandson, who was renown for his wisdom and kindness. He became Billy's Prime Minister. Marries Dora.",
    appearances: ["Dragon Unbound"]
  },
  {
    name: "Tike",
    description: "A lion cub. Grown up Mike's son.",
    appearances: ["Billy The Lion Boy"]
  },
  {
    name: "Tina",
    description: "A lion cub. Grown up Mitch's daughter.",
    appearances: ["Billy The Lion Boy"]
  },
  {
    name: "Toby",
    description: "A dog. Mia's pet golden retriever who views himself as her personal bodyguard.",
    appearances: ["Secret Hero & His Flying Lion"]
  },
  {
    name: "Trevor",
    description: "A human boy. The school bully and one of the bigger boys in St Lydia's Academy.",
    appearances: ["Secret Hero & His Flying Lion"]
  },
  {
    name: "Tucker",
    description: "A mortal boy. Billy's student in St. Lydia's Academy during his first year there as a teacher. Owns Kathy the cat.",
    appearances: ["Dragon Unbound"]
  },
  {
    name: "Teacher Mabel",
    description: "A human woman. A teacher in St Lydia's Academy.",
    appearances: ["Secret Hero & His Flying Lion"]
  },
  {
    name: "Bluma",
    description: "Billy's childhood best friend. Born during the Tribulation, she grows up alongside Billy. In the final story, grown-up Billy and Bluma fall in love, get married, and start a family which becomes a new nation.",
    appearances: ["Emunah Short Stories: Mary's Flight", "Billy & Bluma: Double Trouble", "Secret Hero & His Flying Lion", "Dragon Unbound"]
  },
  {
    name: "Mary",
    description: "A young Jewish woman. Born in the West where her family lived for many generations. Rescued from a lynching mob by Samantha. She makes Aliyah to Israel with Barry's help. Barry and Mary fall in love as they lean on each other to survive when nature turns against humanity during the Tribulation. They flee persecution to a city built in rock. A human woman. Bluma's mother.",
    appearances: ["Emunah Short Stories: Mary's Flight", "Billy & Bluma: Double Trouble", "Dragon Unbound"]
  },
  {
    name: "Barry",
    description: "Mary's landlord in Israel who becomes her love interest. His daughter Natalie was raptured. Barry and Mary join the community around the Two Witnesses and eventually flee to safety together.",
    appearances: ["Emunah Short Stories: Mary's Flight", "The Quest for Immortality"]
  },
  {
    name: "Lina",
    description: "A lioness who becomes Leonard's mate. Together they adopt Billy as their human cub and raise him with their lion cubs. Leonard's mate (wife), which is animal language for wife. Billy's Momma lion.",
    appearances: ["Billy The Lion Boy", "Secret Hero & His Flying Lion", "Dragon Unbound"]
  },
  {
    name: "Two Witnesses",
    description: "2 men. Sent by God to preach the gospel during the 7 year Tribulation. They are invulnerable, breathe fire to kill their attackers, imbued with divine power over the weather and to perform miracles.",
    appearances: ["Emunah Short Stories: Mei", "Emunah Short Stories: Liam's Dark Secrets", "Emunah Short Stories: Mary's Flight"]
  },
  {
    name: "Waru",
    description: "A human man. Koen's father and village chief.",
    appearances: ["Billy The Lion Boy"]
  },
  {
    name: "Sally",
    description: "Middle aged woman. Lydia's mother. Denver's wife.",
    appearances: ["Emunah Short Stories: Lydia's 12 Christmases"]
  },
  {
    name: "Fred",
    description: "Middle aged man. Friend of Oliver and Lydia's parents.",
    appearances: ["Emunah Short Stories: Lydia's 12 Christmases"]
  },
  {
    name: "Gabriel",
    description: "A Jewish man from the tribe of Judah. One of the 144,000 Jewish witnesses sealed by God.",
    appearances: ["Emunah Short Stories: Mei"]
  },
  {
    name: "Greta",
    description: "A mortal woman. Joey's wife. She is a year younger than Joey. They married each other in their forties. She took over Bluma's responsibilities in B's Kingdom when Joey took over Billy's role, to allow Billy and Bluma to take much needed vacations. That arrangement stayed in force until Billy handed the reins to Theodore and Dora.",
    appearances: ["Dragon Unbound"]
  },
  {
    name: "Henrieta Hippo",
    description: "A hippopotamus. Leonard's friend.",
    appearances: ["Billy The Lion Boy"]
  },
  {
    name: "Teacher Elisa",
    description: "A young woman. Lydia's Sunday school teacher who chaperoned the carolling Troup.",
    appearances: ["Emunah Short Stories: Lydia's 12 Christmases"]
  },
  {
    name: "Bryan",
    description: "A young boy. Aaron's Sunday school classmate and confetti nemesis.",
    appearances: ["Emunah Short Stories: Lydia's 12 Christmases"]
  },
  {
    name: "Joey",
    description: "A teenage boy. Lydia's friend from Sunday School. Their families attend the same church. Her crush until her sixteenth birthday. Also a mortal boy/man. Eldest child of Billy and Bluma. Marries Greta.",
    appearances: ["Emunah Short Stories: Lydia's 12 Christmases", "Dragon Unbound"]
  },
  {
    name: "Jill",
    description: "A mortal girl. Billy's student just before he was fired from St. Lydia's Academy.",
    appearances: ["Dragon Unbound"]
  },
  {
    name: "Jim",
    description: "A young Jewish Christian man. Barry's tenant.",
    appearances: ["Emunah Short Stories: Mary's Flight"]
  },
  {
    name: "Jose",
    description: "A human boy. A fellow child prisoner of Junta who tried to escape but got caught and traumatised for it.",
    appearances: ["Billy & Bluma: Double Trouble"]
  },
  {
    name: "Jeremiah",
    description: "A man in his thirties. Also known as Jerry. A scout for the community of outcasts which Mei, Barry and Mary belong to. Thomas's best friend. The pair is known as Tom and Jerry.",
    appearances: ["Emunah Short Stories: Mary's Flight"]
  },
  {
    name: "Troy",
    description: "A teenage boy from Lydia's school. Her first boyfriend.",
    appearances: ["Emunah Short Stories: Lydia's 12 Christmases"]
  },
  {
    name: "Matt",
    description: "A boy. Son of Mary's neighbour.",
    appearances: ["Emunah Short Stories: Mary's Flight"]
  },
  {
    name: "Samantha",
    description: "A young English woman. Also known to her friends as Sam. She is six feet two inches tall with an athletic build. She is a Bible believing born again Christian.",
    appearances: ["Emunah Short Stories: Mary's Flight"]
  },
  {
    name: "Leah",
    description: "A young Jewish woman who is a devout follower of Judaism. Barry's tenant.",
    appearances: ["Emunah Short Stories: Mary's Flight"]
  },
  {
    name: "Mathilda",
    description: "A middle-aged woman. A born again Christian. The midwife for the underground community of new believers in Israel. An immortal. During the 7 Year Tribulation, Mathilda helped take care of Billy and Bluma. She helped Bluma's mother deliver baby Bluma. She also took care of Billy when he was a toddler, allowing him to be her little helper. She was killed for her faith in Christ. After the 7 Year Tribulation, she returned, resurrected as an immortal, to reign with the King of Kings.",
    appearances: ["Emunah Short Stories: Mary's Flight", "Billy & Bluma: Double Trouble"]
  },
  {
    name: "Thomas",
    description: "A man in his thirties. Also known as Tom by his friends. A member of the underground church in Israel and a scout for that community of outcasts.",
    appearances: ["Emunah Short Stories: Mary's Flight"]
  },
  {
    name: "Buck",
    description: "A strong man in his late thirties. A born again Christian in the community of new converts that follows the Jewish evangelists John and Gabriel.",
    appearances: ["Emunah Short Stories: Mary's Flight"]
  },
  {
    name: "Maximus",
    description: "A mortal boy/man. Friend of Joey and Charlotte.",
    appearances: ["Dragon Unbound"]
  }
];

export function getCharacterByName(name: string): Character | undefined {
  return characters.find((c) => c.name.toLowerCase() === name.toLowerCase());
}

export function searchCharacters(query: string): Character[] {
  const lower = query.toLowerCase();
  return characters.filter(
    (c) =>
      c.name.toLowerCase().includes(lower) ||
      c.description.toLowerCase().includes(lower)
  );
}

export function getCharactersByBook(bookTitle: string): Character[] {
  return characters.filter((c) =>
    c.appearances.some((a) => a.toLowerCase().includes(bookTitle.toLowerCase()))
  );
}